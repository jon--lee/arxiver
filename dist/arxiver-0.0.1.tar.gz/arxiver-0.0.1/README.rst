arxiver 0.0.1
-------------

**arxiver is an unoffical API for Cornell's arxiv.org. arxiver returns search results new publications in various topics**

- Contribute on `Github <https://github.com/jon--lee/arxiver>`_

Getting started
+++++++++++++++
Install **arxiver** by running the following command::

    $ pip install arxiver
 

